﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => "Server=LAPTOP-9EQRASUR\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
